<?php
	
	define('HOSTNAME', 'localhost');
	define('USERNAME', 'id8549326_ghifa');
	define('PASSWORD', '123456');
	define('DB_SELECT', 'id8549326_pendataan');

	$koneksi = new mysqli(HOSTNAME,USERNAME,PASSWORD,DB_SELECT) or die(mysql_errno());

?>