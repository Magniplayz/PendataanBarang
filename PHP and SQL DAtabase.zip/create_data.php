<?php 

	include_once('connection.php');

	$kode = $_POST['kode'];
	$nama =	$_POST['nama'];
	$harga = $_POST['harga'];
	$img = $_POST['img'];

	$insert = "INSERT INTO tb_barang(kode,nama,harga,img) VALUES('$kode','$nama','$harga','https://pendataanbarang.000webhostapp.com/php/image/$kode.jpg')";

	$uploadpath = "image/$kode.jpg";
	$exeinsert = mysqli_query($koneksi, $insert);

	$response = array();

	if($exeinsert)
	{
		file_put_contents($uploadpath, base64_decode($img));
		$response['code'] = 1;
		$response['message'] = "Berhasil menambahkan barang... :)";
	}
	else
	{
		$respone['code'] = 0;
		$response['message'] = "Gagal menambahkan barang... :(";
	}

	echo json_encode($response);

 ?>