<?php 

	include_once('connection.php');

	$nama = $_POST['nama'];

	$query = "SELECT * FROM tb_barang WHERE nama LIKE'%$nama%'";
	$result = mysqli_query($koneksi, $query);

	$arraydata = array();

	while($baris = mysqli_fetch_assoc($result))
	{
		$arraydata[] = $baris; 
	}

	echo json_encode($arraydata);

 ?>