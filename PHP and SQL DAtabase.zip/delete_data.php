<?php

	include_once('connection.php');

	$kode = $_POST['kode'];

	$getdata = mysqli_query($koneksi, "SELECT * FROM tb_barang WHERE kode = '$kode'");
	$rows = mysqli_num_rows($getdata);
	$delete = "DELETE FROM tb_barang WHERE kode = '$kode'";
	$exedelete = mysqli_query($koneksi, $delete);

	$response = array();

	if($rows > 0)
	{
		if($exedelete)
		{
			$response['code'] = 1;
			$resonse['message'] = "Delete berhasil";
		}
		else
		{
			$response['code'] = 0;
			$response['message'] = "Delete gagal";
		}
	}
	else
	{
		$response['code'] = 0;
		$response['message'] = "Data tidak ditemukan";
	}

	echo json_encode($response);

?>