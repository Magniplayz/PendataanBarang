<?php 

	include_once('connection.php');

	$kode = $_POST['kode'];
	$nama = $_POST['nama'];
	$harga = $_POST['harga'];
	$img = $_POST['img'];

	$getdata = mysqli_query($koneksi, "SELECT * FROM tb_barang WHERE kode = '$kode'");
	$rows = mysqli_num_rows($getdata);
	$path = "image/$kode.jpg";

	$response = array();

	if($rows > 0)
	{

		$query = "UPDATE tb_barang SET nama='$nama', harga='$harga', img='https://pendataanbarang.000webhostapp.com/php/image/$kode.jpg' WHERE kode='$kode'";
		$exequery = mysqli_query($koneksi, $query);

		if($exequery)
		{
			file_put_contents($path, base64_decode($img));
			$response['code'] = 1;
			$response['message'] = "Update berhasil :)";
		}
		else
		{
			$response['code'] = 0;
			$response['message'] = "Update gagal :(";
		}
	}
	else
	{
		$response['code'] = 0;
		$response['message'] = "Data tidak ditemukan ";
	}

	echo json_encode($response);

 ?>