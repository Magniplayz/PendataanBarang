<?php 

	include_once('connection.php');

	$kode = $_POST['kode'];

	$cekdata = "SELECT * FROM tb_barang WHERE kode = '$kode'";
	$result = mysqli_query($koneksi, $cekdata);

 ?>